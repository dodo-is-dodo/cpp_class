#include <iostream>

int main(int argc, char *argv[])
{
    int a = 3;
    int b = 5;
    std::cout << a + b << "\n";
    std::cout << a - b << "\n";
    std::cout << a * b << "\n";
    std::cout << a / b << "\n";
    return 0;
}
