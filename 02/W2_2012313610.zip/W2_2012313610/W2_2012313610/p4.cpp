#include <iostream>

int main(int argc, char *argv[])
{
    std::string s = "";
    std::cin >> s;
    std::cout << "Hello "<< s << "!\n";
    return 0;
}
