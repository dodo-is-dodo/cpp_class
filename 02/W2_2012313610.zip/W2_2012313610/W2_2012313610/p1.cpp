#include <iostream>

int main(int argc, char *argv[])
{
    std::cout << "I am Mr.Kim." << "\n";
    std::cout << "I am learning C++.";
    return 0;
}
